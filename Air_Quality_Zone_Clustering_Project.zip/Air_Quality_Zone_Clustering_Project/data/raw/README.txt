Place the dataset file here:   data/raw/city_day.csv

Download (manual): https://www.kaggle.com/datasets/rohanrao/air-quality-data-in-india
Use the file named city_day.csv from the downloaded archive.
